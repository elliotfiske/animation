Elliot Fiske

"The mesh was initially created using Cosmic Blobs software developed by Dassault Systemes SolidWorks Corp."

Whole assignment completed, but not extra credit

The CPU skinning started going a little weird at the last second - some vertices are slightly nudged from where they should be. GPU is perfect though.
